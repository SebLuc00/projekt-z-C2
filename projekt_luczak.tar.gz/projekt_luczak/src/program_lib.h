

#ifndef PROGRAM_LIB_H_
#define PROGRAM_LIB_H_

//Strktura listy wiązanej
struct Node {
	int id;
	unsigned char *datagram;
	struct Node *next;
	struct Node *prev;
};


void * LoadIpv6 ();	//funkcja deklaracji di łdadowania ipv6
void * LoadUdp ();	//funkcja deklaracji di łdadowania biblioteki udp

void SendPacket (unsigned char *interface );	//funkcja do wysyłąnia pakietów z listy wiązanej
void LoadToList ( int *count, unsigned char *dtgr );	//funkcja ładowania danych do listy wiazanej

struct Node *ReserveMem ( unsigned char *datagram );	//funkcja rezerwacji pamieci dla nowej listy wiazanej
void InsertTail ( unsigned char *datagram );	//funkcja ustawienia nowego elementu na koncu listy
void PrintList ();	//printowanie listy wiazanej
void DeleteList ();	//usuwanie listy wiaznej
struct Node * ReturnHead (); //zwracanie nagłówka listy

#endif /* PROGRAM_LIB_H_ */
