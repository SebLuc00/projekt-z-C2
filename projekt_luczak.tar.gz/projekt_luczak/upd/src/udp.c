#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>           // close()
#include <string.h>           // strcpy, memset(), and memcpy()

#include <netinet/in.h>       // IPPROTO_RAW, IPPROTO_UDP, INET6_ADDRSTRLEN
#include <netinet/ip6.h>      // struct ip6_hdr
#include <netinet/udp.h>


void CreateUDPPacket (unsigned char *datagram) {	//przyjmij pakiet ipv6

	struct ip6_hdr *iphdr = (struct ip6_hdr*) datagram;
	char input [32];
	//pamięc za nagłóœkiem ipv6 traktuj jako udp
	struct udphdr *udp = (struct udphdr *) (datagram + sizeof (struct ip6_hdr));
	char *udp_data = datagram + sizeof (struct ip6_hdr) + sizeof (struct udphdr);

	printf ("UDP source (1000):");
	fgets (input, 32, stdin);
	if (atoi(input)== 0)          //atoi pobiera liczbę w postaci ciągu znaków ASCII, a następnie zwraca jej wartość w formacie int
		udp->source = htons (1000);	//port źródłowy

	else
		udp->source = htons (atoi (input));

	printf ("UDP destination (2000):");
	fgets (input, 32, stdin);
	if (atoi(input)== 0)
		udp->dest = htons (2000);	//porto docelowy
	else
		udp->dest = htons (atoi (input));

	printf ("DATA:");
	fgets (input, 32, stdin);
	memcpy ( udp_data, input, strlen (input)-1 ); //skopiju dane do miejsca w pamięci przeznaczonego na dane

	udp->check = 0;		//suma kontrolna wypełniana w program_lib.c
	udp->len = htons (sizeof (struct udphdr) + strlen(udp_data));	//obliczenie długiości pakietu udp

	iphdr->ip6_ctlun.ip6_un1.ip6_un1_plen = udp->len;	//dodanie wielkości pakietu udp do długości ipv6


}



