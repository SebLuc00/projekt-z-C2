
#ifndef SRC_ICMP6_H_
#define SRC_ICMP6_H_

void CreateUDPPacket (unsigned char *datagram);

#endif /* SRC_ICMP6_H_ */
