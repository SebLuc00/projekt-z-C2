#!/bin/bash
gcc -fPIC -shared ~/projekt_luczak/ipv6/src/ipv6.c -o /home/konrad/projekt_luczak/Debug/ipv6.so
gcc -fPIC -shared ~/projekt_luczak/upd/src/udp.c -o /home/konrad/projekt_luczak/Debug/udp.so
