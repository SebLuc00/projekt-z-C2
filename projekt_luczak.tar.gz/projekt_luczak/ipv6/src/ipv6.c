
#include <stdio.h>
#include <stdlib.h>
#include <string.h>           // strcpy, memset(), and memcpy()

#include <netinet/in.h>       // IPPROTO_RAW, IPPROTO_UDP, INET6_ADDRSTRLEN
#include <netinet/ip6.h>      // struct ip6_hdr






unsigned char * CreateIPV6Packet (){
	//funkcja zwrCA WSKAŹNIK DO PAMIĘCI ,

	unsigned char *datagram = malloc (4096);	//rezerwujemy pamiec dla pakietu
	struct ip6_hdr *iphdr = (struct ip6_hdr *) datagram;    //structura nagłówka, na początku datagramu (pakietu)
	char input [32]; //tablica pomocnicza

	printf ("Version set to default (6)\n");
	iphdr->ip6_ctlun.ip6_un1.ip6_un1_flow = htonl ((6 << 28) | (0 << 20) | 0); //ustawianie wersji, przepływu

	printf ("Hop limit: (255): ");	//czas życia
	fgets (input, 32, stdin);	//funkcja wczytująca
	if (atoi(input)== 0)
		iphdr->ip6_ctlun.ip6_un1.ip6_un1_hlim = 255;	//strzałka bo strutura, kropka bo unia
	else
		iphdr->ip6_ctlun.ip6_un1.ip6_un1_hlim = atoi (input);  //atoi pobiera liczbę w postaci ciągu znaków ASCII, a następnie zwraca jej wartość w formacie int

	printf ("Payload will be calculated\n");

	printf ("Type protocol:\n[0:IPv6] [1:UDP]: ");
	fgets (input, 32, stdin);
	if (atoi(input)== 0)
		iphdr->ip6_ctlun.ip6_un1.ip6_un1_nxt = IPPROTO_RAW;	//ustawienie następnego protokołu
	else
		iphdr->ip6_ctlun.ip6_un1.ip6_un1_nxt = IPPROTO_UDP;

	if (iphdr->ip6_ctlun.ip6_un1.ip6_un1_nxt == IPPROTO_RAW){
		printf ("Type msg to send: ");
		fgets (input, 32, stdin);
//przejdz do adresu za nagłówiekiem IP i wklej tam dane do wysłania
		strcpy((char*)datagram+sizeof(struct ip6_hdr), input);
	}

	iphdr->ip6_ctlun.ip6_un1.ip6_un1_plen = htons((short)strlen(input)-1);	//oblicz długość pakietu



	return datagram;		//zwróć pakiet
}

