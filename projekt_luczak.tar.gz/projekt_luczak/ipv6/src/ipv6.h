

#ifndef SRC_IPV6_H_
#define SRC_IPV6_H_



unsigned char * CreateIPV6Packet ();

#endif /* SRC_IPV6_H_ */
